#Group Bravo
#Module 10
#Outland Adventures
import mysql.connector
from mysql.connector import errorcode

mydb = mysql.connector.connect(
  host="127.0.0.1",
  user="root",
  password="TabyTigr#082021"
)

mycursor = mydb.cursor()

mycursor.execute("CREATE DATABASE outland_adventures")