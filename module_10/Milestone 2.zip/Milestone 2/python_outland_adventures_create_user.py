# Bravo Group
#CSD-310 Module 10
#Milestone 2 - Create User


import mysql.connector
from mysql.connector import errorcode


config = {
    "user": "root",
    "password": "TabyTigr#082021",
    "host": "127.0.0.1",
    "database": "outland_adventures",
    "raise_on_warnings": True
}

try:
    db = mysql.connector.connect(**config)
    cursor = db.cursor()
   # cursor = db.cursor()
    cursor.execute = ("USE outland_adventures")
    db.commit()
    cursor.execute = ("DROP USER IF EXISTS 'outland_adventures_user'@'localhost")
    db.commit()
    cursor.execute = ("CREATE USER 'out_adventures_user'@'localhost' IDENTIFIED WITH mysql_native_password BY 'MySQL8IsGreat!'")
    db.commit()
    cursor.execute = ("GRANT ALL PRIVILEGES ON outland_adventures.*    TO'out_adventures_user'@'localhost'")
    db.commit()    
    
       
   
    print("\n Database user {} connected to MySQL on host {} with database {}".format(config["user"], config["host"], config["database"]))
   
    input("\n\n Press any key to continue...")

except mysql.connector.Error as err:
    if err.errno == errorcode.ER_ACCESS_DENIED_ERROR:
        print(" The supplied username or password are invalid.")

    elif err.errno == errorcode.ER_BAD_DB_ERROR:
        print(" The specified database does not exist.")

    else:
        print(err)
    
else:
    db.close()