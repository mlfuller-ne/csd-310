#Group Bravo
#Module 11
#Outland Adventures

import mysql.connector
from mysql.connector import errorcode

config = {
    'user': 'root',
    'password' : '12345',
    'host': '127.0.0.1',
    'database': 'outland_adventures',
    'raise_on_warnings': True
}

try:
    db = mysql.connector.connect(**config)

except mysql.connector.Error as err:
    if err.errno == errorcode.ER_ACCESS_DENIED_ERROR:
        print("  The supplied username or password are invalid")

    elif err.errno == errorcode.ER_BAD_DB_ERROR:
        print("  The specified database does not exist")

    else:
        print(err)

cursor = db.cursor()

def printTable(results,cursor):
    widths = []
    columns = []
    tavnit = '|'
    separator = '+' 

    for column,cd in enumerate(cursor.description):
        width = len(cd[0])
        for rowNumber in range(len(response)):
            if len(str(response[rowNumber][column])) > width:
                width = len(str(response[rowNumber][column]))
        widths.append(width)
        columns.append(cd[0])

    for w in widths:
        tavnit += " %-"+"%ss |" % (w,)
        separator += '-'*w + '--+'

    print(separator)
    print(tavnit % tuple(columns))
    print(separator)
    for row in results:
        print(tavnit % row)
    print(separator)
    print()


cursor.execute("Use outland_adventures")

# REPORT 1
cursor = db.cursor()
cursor.execute("""SELECT count(*), Year(s.date_of_sale), SUM(s.final_equipment_price), SUM(e.equipment_cost)
                FROM equipment_sales s
                INNER JOIN equipment e on e.equipment_id = s.equipment_id
                Group by Year(s.date_of_sale)
                ;""")
response = cursor.fetchall()
if response:
    print("\n-- Report 1: Rev/Cost --")
    printTable(response,cursor)
else:
    print("No data to be found here.")
    
# REPORT 2
cursor = db.cursor()
cursor.execute("""SELECT distinct location_continent, count(customer_id), Year(order_date)
                FROM orders
                INNER JOIN trek
                    ON orders.trek_id = trek.trek_id
                Group by location_continent, Year(order_date)
                ;""")
response = cursor.fetchall()
if response:
    print("\n-- Report 2: Trip Order Records --")
    printTable(response,cursor)
else:
    print("No data to be found here.")

# REPORT 3
cursor.execute("SELECT equipment_type, expiration_date FROM equipment")
response = cursor.fetchall()
if response:
    print("\n-- Report 3: Equipment Expiration Records --")
    printTable(response,cursor)
else:
    print("No data to be found here.")
